### Hexlet tests and linter status:
[![Actions Status](https://github.com/pgchurikov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/pgchurikov/python-project-49/actions)

<a href="https://codeclimate.com/github/pgchurikov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bd64c5cc50195b932e22/maintainability" /></a>
